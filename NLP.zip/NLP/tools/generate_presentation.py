"""Generate a PowerPoint presentation summarizing the AfriSenti sentiment analysis project.

This script collects brief text from `README.md`, `REPORT.md`, example EDA images (if any in ./data or ./eda), and code snippets from `src/` to create `AfriSenti_presentation.pptx`.

Run:
    python tools\generate_presentation.py

Requirements: python-pptx (added to requirements.txt)
"""
import os
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt

ROOT = Path('c:/Users/BMC/Desktop/NLP')
OUT = ROOT / 'AfriSenti_presentation.pptx'


def read_text_file(p: Path):
    if p.exists():
        return p.read_text(encoding='utf-8')
    return ''


def add_title_slide(prs, title, subtitle=''):
    slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(slide_layout)
    title_tf = slide.shapes.title
    subtitle_tf = slide.placeholders[1]
    title_tf.text = title
    subtitle_tf.text = subtitle


def add_text_slide(prs, heading, body, max_chars=1200):
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = heading
    tx = slide.shapes.placeholders[1].text_frame
    # split into paragraphs to keep slides readable
    if len(body) > max_chars:
        body = body[:max_chars] + '\n\n(Truncated; see REPORT.md for full details)'
    for i, line in enumerate(body.split('\n')):
        p = tx.add_paragraph() if i>0 else tx.paragraphs[0]
        p.text = line
        p.font.size = Pt(14)


def add_code_slide(prs, heading, code_snippet, max_lines=20):
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = heading
    tx = slide.shapes.placeholders[1].text_frame
    lines = code_snippet.split('\n')
    if len(lines) > max_lines:
        lines = lines[:max_lines] + ['# ... (truncated)']
    for i, line in enumerate(lines):
        p = tx.add_paragraph() if i>0 else tx.paragraphs[0]
        p.text = line
        p.font.size = Pt(12)


def add_image_slide(prs, heading, image_path: Path):
    slide_layout = prs.slide_layouts[5]
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = heading
    left = Inches(0.5)
    top = Inches(1.5)
    width = Inches(9)
    try:
        slide.shapes.add_picture(str(image_path), left, top, width=width)
    except Exception as e:
        slide.shapes.placeholders[1].text = f'Image could not be loaded: {e}'


def gather_eda_images(root: Path):
    candidates = list(root.glob('**/eda*.png')) + list(root.glob('**/char_len_dist.png')) + list(root.glob('**/*_len_dist.png'))
    unique = []
    seen = set()
    for p in candidates:
        if p.name not in seen:
            unique.append(p)
            seen.add(p.name)
    return unique


def main():
    prs = Presentation()
    # Title
    add_title_slide(prs, 'AfriSenti Multilingual Sentiment Analysis', 'Swahili | Amharic | English')

    # README
    readme = read_text_file(ROOT / 'README.md')
    add_text_slide(prs, 'Project Overview (README)', readme)

    # REPORT
    report = read_text_file(ROOT / 'REPORT.md')
    if report:
        add_text_slide(prs, 'Short Report (Summary)', report)

    # EDA images
    eda_imgs = gather_eda_images(ROOT)
    if eda_imgs:
        for img in eda_imgs[:6]:
            add_image_slide(prs, f'EDA: {img.stem}', img)
    else:
        add_text_slide(prs, 'EDA', 'No EDA images found in the project. Run the notebook to generate plots (they will be saved in data/ or the project root).')

    # Preprocessing summary from src/preprocess.py
    preprocess_txt = read_text_file(ROOT / 'src' / 'preprocess.py')
    if preprocess_txt:
        # extract top-level function names and a brief excerpt
        excerpt = '\n'.join(preprocess_txt.splitlines()[:60])
        add_code_slide(prs, 'Preprocessing (src/preprocess.py)', excerpt)

    # Tokenizer and model snippets
    tokenizer_txt = read_text_file(ROOT / 'src' / 'tokenize_utils.py')
    model_txt = read_text_file(ROOT / 'src' / 'models.py')
    if tokenizer_txt:
        add_code_slide(prs, 'Tokenizers (src/tokenize_utils.py)', '\n'.join(tokenizer_txt.splitlines()[:60]))
    if model_txt:
        add_code_slide(prs, 'Models (src/models.py)', '\n'.join(model_txt.splitlines()[:80]))

    # Training example (run_all)
    run_all_txt = read_text_file(ROOT / 'src' / 'run_all.py')
    if run_all_txt:
        add_code_slide(prs, 'Run script (src/run_all.py)', '\n'.join(run_all_txt.splitlines()[:80]))

    # Where to find results
    add_text_slide(prs, 'Artifacts & Next Steps', 'When you run the notebook, save artifacts:\n- Model checkpoint: best_xlmroberta.pt\n- Tokenizer: tokenizer.save_pretrained(path)\n- EDA plots: saved as PNGs in project root or data/\n\nRun the presentation generator and attach the generated PPTX to reports or slides.')

    # Save
    try:
        prs.save(str(OUT))
        print(f'Presentation saved to: {OUT}')
    except Exception as e:
        print('Failed to save presentation:', e)


if __name__ == '__main__':
    main()
